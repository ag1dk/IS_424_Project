from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.urls import reverse
from .models import items, Cart
from django.shortcuts import render, redirect, get_object_or_404
from .forms import ItemForm

from .models import User
from .models import items

def index(request):
    return render(request, "auctions/index.html", {
        "auctions": items.objects.all()
    })


def login_view(request):
    if request.method == "POST":

        
        username = request.POST["username"]
        password = request.POST["password"]
        user = authenticate(request, username=username, password=password)

        
        if user is not None:
            login(request, user)
            return HttpResponseRedirect(reverse("index"))
        else:
            return render(request, "auctions/login.html", {
                "message": "Invalid username and/or password."
            })
    else:
        return render(request, "auctions/login.html")


def logout_view(request):
    logout(request)
    return HttpResponseRedirect(reverse("index"))


def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]

        
        password = request.POST["password"]
        confirmation = request.POST["confirmation"]
        if password != confirmation:
            return render(request, "auctions/register.html", {
                "message": "Passwords must match."
            })

        
        try:
            user = User.objects.create_user(username, email, password)
            user.save()
        except IntegrityError:
            return render(request, "auctions/register.html", {
                "message": "Username already taken."
            })
        login(request, user)
        return HttpResponseRedirect(reverse("index"))
    else:
        return render(request, "auctions/register.html")
    
def index(request):
    return render(request, "auctions/index.html", {
        "auctions": items.objects.all()
    })


def item(request, item_id):
    item = items.objects.get(pk=item_id)
    return render(request, "auctions/item.html", {
        "item": item
    })


def add_to_cart(request, item_id):
    item = items.objects.get(pk=item_id)
    cart, created = Cart.objects.get_or_create(user=request.user)
    cart.items.add(item)
    return redirect('item', item_id=item_id)



def view_cart(request):
    cart = Cart.objects.get(user=request.user)
    items = cart.items.all()
    total_price = sum([item.price for item in items])
    return render(request, 'auctions/cart.html', {'items': items, 'total_price': total_price})

def item_list(request):
    items = items.objects.all()
    return render(request, 'auctions/item_list.html', {'items': items, 'add_item_url': '/add_item/'})

def add_item(request):
    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('item_list')
    else:
        form = ItemForm()
    return render(request, 'auctions/add_item.html', {'form': form})

def edit_item(request, item_id):
    item = get_object_or_404(items, pk=item_id)

    if request.method == 'POST':
        form = ItemForm(request.POST, request.FILES, instance=item)
        if form.is_valid():
            form.save()
            return redirect('item', item_id=item_id)
    else:
        form = ItemForm(instance=item)

    context = {
        'form': form,
        'submit_button_text': 'Save Changes',
        'cancel_url': reverse('item', args=[item_id]),
    }
    return render(request, 'auctions/add_item.html', context)

def remove_from_cart(request, item_id):
    item = items.objects.get(pk=item_id)
    cart = Cart.objects.get(user=request.user)
    cart.items.remove(item)
    return redirect('view_cart')





